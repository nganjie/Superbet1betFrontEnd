export const environment = {
  production: true,  
  url:"https://super1bet237.com/api/"
};
