export class TypePari {
    constructor(
        public nom: string,
        public description: string,
        public raccourci: string
    ) {}
}


