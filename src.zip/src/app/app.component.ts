import { Component } from '@angular/core';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'keno-front';

  messages: string[] = [];
  message: any;
  private socket!: WebSocket;
  public serverMessages: string[] = [];
  private subscription: Subscription | null = null;

  ngOnInit(): void {
    // Code de salle à envoyer au serveur
    const codeSalle = 'S001000'; // Remplacez ceci par le code de salle réel

    this.socket = new WebSocket('ws://super1bet237.com:8080');

    this.socket.onopen = () => {
      console.log('Connected to WebSocket server');

      // Envoyer le code de salle après l'ouverture de la connexion
      this.socket.send(JSON.stringify({ type: 'join', code_salle: codeSalle }));
    };

    // Événement déclenché lorsqu'un message est reçu du serveur
    this.socket.onmessage = (event) => {
      this.handleMessage(event.data);
    };

    this.socket.onclose = () => {
      console.log('Disconnected from WebSocket server');
    };   

    // Appel de handleMessage() toutes les 5 secondes (si nécessaire)
    setInterval(() => {
      if (this.message) { // Vérifiez si un message a été reçu
        this.handleMessage(this.message);
      }
    }, 5000);

    // Initialisation des paramètres de langue pour le service de traduction
 
  }

  handleMessage(data: any) {
    console.log('Message from server:', data);
    this.message = data;

    // Si data est une chaîne JSON, il faut la parser
    if (typeof data === 'string') {
      try {
        data = JSON.parse(data);
      } catch (error) {
        console.error('Failed to parse JSON:', error);
        return; // Sortir si l'analyse échoue
      }
    }

    // Vérification du format après l'analyse
    console.log('Parsed data:', data);
    console.log('Type of data:', typeof data);

    // Accéder à algo_en_cours
    if (Array.isArray(data) && data.length > 0 && data[0].algo_en_cours !== undefined) {
      console.log(data[0].algo_en_cours); // Affiche la valeur de algo_en_cours
    } else {
      console.log('algo_en_cours not found in the data received.');
    }
  }




  sendMessage(message: string) {
    this.socket.send(message);
  }
  
  
}
