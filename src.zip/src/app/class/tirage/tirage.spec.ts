import { Tirage } from './tirage';

describe('Tirage', () => {
  it('should create an instance', () => {
    expect(new Tirage()).toBeTruthy();
  });
});
