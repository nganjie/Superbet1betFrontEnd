import { Paramjeu } from './paramjeu';

describe('Paramjeu', () => {
  it('should create an instance', () => {
    expect(new Paramjeu()).toBeTruthy();
  });
});
