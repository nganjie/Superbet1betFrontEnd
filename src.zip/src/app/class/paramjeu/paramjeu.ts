export class Paramjeu {
    boules: number[];
    multiplicateur: number;
    cagnotte:string;
    jackpot:string;
    megajackpot:string;
    wincagnotte:number;
  }
