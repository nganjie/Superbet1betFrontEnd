import { Multiplicateur } from './multiplicateur';

describe('Multiplicateur', () => {
  it('should create an instance', () => {
    expect(new Multiplicateur()).toBeTruthy();
  });
});
