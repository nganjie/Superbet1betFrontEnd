export class Multiplicateur {
    multiplicateur:number
    dateHeure:string
}
