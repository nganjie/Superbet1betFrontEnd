export class Boule {
    numboule:number
}
