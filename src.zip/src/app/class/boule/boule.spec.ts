import { Boule } from './boule';

describe('Boule', () => {
  it('should create an instance', () => {
    expect(new Boule()).toBeTruthy();
  });
});
